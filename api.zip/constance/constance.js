module.exports = {
    OK: "ok",
    NOK: "nok",
  };
  